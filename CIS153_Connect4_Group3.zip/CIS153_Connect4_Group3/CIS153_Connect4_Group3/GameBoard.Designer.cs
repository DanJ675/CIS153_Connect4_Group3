﻿
namespace Connect4
{
    partial class GameBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listView1 = new System.Windows.Forms.ListView();
            this.col6Panel = new System.Windows.Forms.Panel();
            this.pBox51P1 = new System.Windows.Forms.PictureBox();
            this.pBox01P2 = new System.Windows.Forms.PictureBox();
            this.pBox01P0 = new System.Windows.Forms.PictureBox();
            this.pBox01P1 = new System.Windows.Forms.PictureBox();
            this.pBox11P2 = new System.Windows.Forms.PictureBox();
            this.pBox11P0 = new System.Windows.Forms.PictureBox();
            this.pBox11P1 = new System.Windows.Forms.PictureBox();
            this.pBox21P2 = new System.Windows.Forms.PictureBox();
            this.pBox21P0 = new System.Windows.Forms.PictureBox();
            this.pBox21P1 = new System.Windows.Forms.PictureBox();
            this.pBox31P2 = new System.Windows.Forms.PictureBox();
            this.pBox31P0 = new System.Windows.Forms.PictureBox();
            this.pBox31P1 = new System.Windows.Forms.PictureBox();
            this.pBox41P2 = new System.Windows.Forms.PictureBox();
            this.pBox41P0 = new System.Windows.Forms.PictureBox();
            this.pBox41P1 = new System.Windows.Forms.PictureBox();
            this.pBox51P2 = new System.Windows.Forms.PictureBox();
            this.pBox51P0 = new System.Windows.Forms.PictureBox();
            this.col1Panel = new System.Windows.Forms.Panel();
            this.pBox02P1 = new System.Windows.Forms.PictureBox();
            this.pBox02P2 = new System.Windows.Forms.PictureBox();
            this.pBox02P0 = new System.Windows.Forms.PictureBox();
            this.pBox12P2 = new System.Windows.Forms.PictureBox();
            this.pBox12P0 = new System.Windows.Forms.PictureBox();
            this.pBox12P1 = new System.Windows.Forms.PictureBox();
            this.pBox22P2 = new System.Windows.Forms.PictureBox();
            this.pBox22P0 = new System.Windows.Forms.PictureBox();
            this.pBox22P1 = new System.Windows.Forms.PictureBox();
            this.pBox32P2 = new System.Windows.Forms.PictureBox();
            this.pBox32P0 = new System.Windows.Forms.PictureBox();
            this.pBox32P1 = new System.Windows.Forms.PictureBox();
            this.pBox42P2 = new System.Windows.Forms.PictureBox();
            this.pBox42P0 = new System.Windows.Forms.PictureBox();
            this.pBox42P1 = new System.Windows.Forms.PictureBox();
            this.pBox52P2 = new System.Windows.Forms.PictureBox();
            this.pBox52P0 = new System.Windows.Forms.PictureBox();
            this.pBox52P1 = new System.Windows.Forms.PictureBox();
            this.col2Panel = new System.Windows.Forms.Panel();
            this.pBox53P1 = new System.Windows.Forms.PictureBox();
            this.pBox03P2 = new System.Windows.Forms.PictureBox();
            this.pBox03P0 = new System.Windows.Forms.PictureBox();
            this.pBox03P1 = new System.Windows.Forms.PictureBox();
            this.pBox13P2 = new System.Windows.Forms.PictureBox();
            this.pBox13P0 = new System.Windows.Forms.PictureBox();
            this.pBox13P1 = new System.Windows.Forms.PictureBox();
            this.pBox23P2 = new System.Windows.Forms.PictureBox();
            this.pBox23P0 = new System.Windows.Forms.PictureBox();
            this.pBox23P1 = new System.Windows.Forms.PictureBox();
            this.pBox33P2 = new System.Windows.Forms.PictureBox();
            this.pBox33P0 = new System.Windows.Forms.PictureBox();
            this.pBox33P1 = new System.Windows.Forms.PictureBox();
            this.pBox43P2 = new System.Windows.Forms.PictureBox();
            this.pBox43P0 = new System.Windows.Forms.PictureBox();
            this.pBox43P1 = new System.Windows.Forms.PictureBox();
            this.pBox53P2 = new System.Windows.Forms.PictureBox();
            this.pBox53P0 = new System.Windows.Forms.PictureBox();
            this.col3Panel = new System.Windows.Forms.Panel();
            this.pBox54P1 = new System.Windows.Forms.PictureBox();
            this.pBox04P0 = new System.Windows.Forms.PictureBox();
            this.pBox04P1 = new System.Windows.Forms.PictureBox();
            this.pBox14P2 = new System.Windows.Forms.PictureBox();
            this.pBox14P0 = new System.Windows.Forms.PictureBox();
            this.pBox14P1 = new System.Windows.Forms.PictureBox();
            this.pBox24P2 = new System.Windows.Forms.PictureBox();
            this.pBox24P0 = new System.Windows.Forms.PictureBox();
            this.pBox24P1 = new System.Windows.Forms.PictureBox();
            this.pBox34P2 = new System.Windows.Forms.PictureBox();
            this.pBox34P0 = new System.Windows.Forms.PictureBox();
            this.pBox34P1 = new System.Windows.Forms.PictureBox();
            this.pBox44P2 = new System.Windows.Forms.PictureBox();
            this.pBox44P0 = new System.Windows.Forms.PictureBox();
            this.pBox44P1 = new System.Windows.Forms.PictureBox();
            this.pBox54P2 = new System.Windows.Forms.PictureBox();
            this.pBox54P0 = new System.Windows.Forms.PictureBox();
            this.pBox04P2 = new System.Windows.Forms.PictureBox();
            this.col4Panel = new System.Windows.Forms.Panel();
            this.pBox55P1 = new System.Windows.Forms.PictureBox();
            this.pBox05P2 = new System.Windows.Forms.PictureBox();
            this.pBox05P0 = new System.Windows.Forms.PictureBox();
            this.pBox05P1 = new System.Windows.Forms.PictureBox();
            this.pBox15P2 = new System.Windows.Forms.PictureBox();
            this.pBox15P0 = new System.Windows.Forms.PictureBox();
            this.pBox15P1 = new System.Windows.Forms.PictureBox();
            this.pBox25P2 = new System.Windows.Forms.PictureBox();
            this.pBox25P0 = new System.Windows.Forms.PictureBox();
            this.pBox25P1 = new System.Windows.Forms.PictureBox();
            this.pBox35P2 = new System.Windows.Forms.PictureBox();
            this.pBox35P0 = new System.Windows.Forms.PictureBox();
            this.pBox35P1 = new System.Windows.Forms.PictureBox();
            this.pBox45P2 = new System.Windows.Forms.PictureBox();
            this.pBox45P0 = new System.Windows.Forms.PictureBox();
            this.pBox45P1 = new System.Windows.Forms.PictureBox();
            this.pBox55P2 = new System.Windows.Forms.PictureBox();
            this.pBox55P0 = new System.Windows.Forms.PictureBox();
            this.pBox40P2 = new System.Windows.Forms.PictureBox();
            this.pBox40P1 = new System.Windows.Forms.PictureBox();
            this.pBox30P2 = new System.Windows.Forms.PictureBox();
            this.pBox20P2 = new System.Windows.Forms.PictureBox();
            this.pBox20P1 = new System.Windows.Forms.PictureBox();
            this.pBox40P0 = new System.Windows.Forms.PictureBox();
            this.pBox30P1 = new System.Windows.Forms.PictureBox();
            this.pBox30P0 = new System.Windows.Forms.PictureBox();
            this.pBox20P0 = new System.Windows.Forms.PictureBox();
            this.pBox10P2 = new System.Windows.Forms.PictureBox();
            this.pBox10P1 = new System.Windows.Forms.PictureBox();
            this.pBox10P0 = new System.Windows.Forms.PictureBox();
            this.pBox00P1 = new System.Windows.Forms.PictureBox();
            this.pBox00P0 = new System.Windows.Forms.PictureBox();
            this.pBox50P0 = new System.Windows.Forms.PictureBox();
            this.pBox50P2 = new System.Windows.Forms.PictureBox();
            this.pBox00P2 = new System.Windows.Forms.PictureBox();
            this.pBox50P1 = new System.Windows.Forms.PictureBox();
            this.col0 = new System.Windows.Forms.Panel();
            this.col5Panel = new System.Windows.Forms.Panel();
            this.pBox56P1 = new System.Windows.Forms.PictureBox();
            this.pBox06P1 = new System.Windows.Forms.PictureBox();
            this.pBox16P1 = new System.Windows.Forms.PictureBox();
            this.pBox26P1 = new System.Windows.Forms.PictureBox();
            this.pBox36P1 = new System.Windows.Forms.PictureBox();
            this.pBox46P1 = new System.Windows.Forms.PictureBox();
            this.pBox56P2 = new System.Windows.Forms.PictureBox();
            this.pBox06P2 = new System.Windows.Forms.PictureBox();
            this.pBox16P2 = new System.Windows.Forms.PictureBox();
            this.pBox26P2 = new System.Windows.Forms.PictureBox();
            this.pBox36P2 = new System.Windows.Forms.PictureBox();
            this.pBox46P2 = new System.Windows.Forms.PictureBox();
            this.pBox06P0 = new System.Windows.Forms.PictureBox();
            this.pBox16P0 = new System.Windows.Forms.PictureBox();
            this.pBox26P0 = new System.Windows.Forms.PictureBox();
            this.pBox36P0 = new System.Windows.Forms.PictureBox();
            this.pBox46P0 = new System.Windows.Forms.PictureBox();
            this.pBox56P0 = new System.Windows.Forms.PictureBox();
            this.ExitButt = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pBoxPlayer1 = new System.Windows.Forms.PictureBox();
            this.lblPlayer1Name = new System.Windows.Forms.Label();
            this.lblPlayer2Name = new System.Windows.Forms.Label();
            this.pBoxPlayer2 = new System.Windows.Forms.PictureBox();
            this.col6Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox51P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox01P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox01P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox01P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox11P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox11P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox11P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox21P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox21P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox21P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox31P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox31P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox31P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox41P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox41P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox41P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox51P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox51P0)).BeginInit();
            this.col1Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox02P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox02P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox02P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox12P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox12P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox12P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox22P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox22P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox22P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox32P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox32P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox32P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox42P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox42P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox42P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox52P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox52P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox52P1)).BeginInit();
            this.col2Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox53P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox03P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox03P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox03P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox13P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox13P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox13P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox23P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox23P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox23P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox33P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox33P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox33P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox43P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox43P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox43P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox53P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox53P0)).BeginInit();
            this.col3Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox54P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox04P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox04P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox14P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox14P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox14P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox24P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox24P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox24P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox34P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox34P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox34P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox44P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox44P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox44P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox54P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox54P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox04P2)).BeginInit();
            this.col4Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox55P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox05P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox05P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox05P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox15P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox15P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox15P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox25P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox25P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox25P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox35P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox35P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox35P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox45P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox45P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox45P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox55P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox55P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox40P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox40P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox30P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox20P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox20P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox40P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox30P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox30P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox20P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox10P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox10P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox10P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox00P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox00P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox50P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox50P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox00P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox50P1)).BeginInit();
            this.col0.SuspendLayout();
            this.col5Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox56P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox06P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox16P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox26P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox36P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox46P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox56P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox06P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox16P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox26P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox36P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox46P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox06P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox16P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox26P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox36P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox46P0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox56P0)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxPlayer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxPlayer2)).BeginInit();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(39, 32);
            this.listView1.Margin = new System.Windows.Forms.Padding(4);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(389, 332);
            this.listView1.TabIndex = 1;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // col6Panel
            // 
            this.col6Panel.BackColor = System.Drawing.Color.LemonChiffon;
            this.col6Panel.Controls.Add(this.pBox51P1);
            this.col6Panel.Controls.Add(this.pBox01P2);
            this.col6Panel.Controls.Add(this.pBox01P0);
            this.col6Panel.Controls.Add(this.pBox01P1);
            this.col6Panel.Controls.Add(this.pBox11P2);
            this.col6Panel.Controls.Add(this.pBox11P0);
            this.col6Panel.Controls.Add(this.pBox11P1);
            this.col6Panel.Controls.Add(this.pBox21P2);
            this.col6Panel.Controls.Add(this.pBox21P0);
            this.col6Panel.Controls.Add(this.pBox21P1);
            this.col6Panel.Controls.Add(this.pBox31P2);
            this.col6Panel.Controls.Add(this.pBox31P0);
            this.col6Panel.Controls.Add(this.pBox31P1);
            this.col6Panel.Controls.Add(this.pBox41P2);
            this.col6Panel.Controls.Add(this.pBox41P0);
            this.col6Panel.Controls.Add(this.pBox41P1);
            this.col6Panel.Controls.Add(this.pBox51P2);
            this.col6Panel.Controls.Add(this.pBox51P0);
            this.col6Panel.Location = new System.Drawing.Point(104, 73);
            this.col6Panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.col6Panel.Name = "col6Panel";
            this.col6Panel.Size = new System.Drawing.Size(48, 289);
            this.col6Panel.TabIndex = 173;
            this.col6Panel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col1_MouseClick);
            this.col6Panel.MouseLeave += new System.EventHandler(this.col1_MouseLeave);
            this.col6Panel.MouseHover += new System.EventHandler(this.col1_MouseHover);
            // 
            // pBox51P1
            // 
            this.pBox51P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox51P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox51P1.Location = new System.Drawing.Point(3, 6);
            this.pBox51P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox51P1.Name = "pBox51P1";
            this.pBox51P1.Size = new System.Drawing.Size(44, 39);
            this.pBox51P1.TabIndex = 210;
            this.pBox51P1.TabStop = false;
            // 
            // pBox01P2
            // 
            this.pBox01P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox01P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox01P2.Location = new System.Drawing.Point(3, 229);
            this.pBox01P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox01P2.Name = "pBox01P2";
            this.pBox01P2.Size = new System.Drawing.Size(44, 39);
            this.pBox01P2.TabIndex = 193;
            this.pBox01P2.TabStop = false;
            // 
            // pBox01P0
            // 
            this.pBox01P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox01P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox01P0.Location = new System.Drawing.Point(3, 229);
            this.pBox01P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox01P0.Name = "pBox01P0";
            this.pBox01P0.Size = new System.Drawing.Size(44, 39);
            this.pBox01P0.TabIndex = 194;
            this.pBox01P0.TabStop = false;
            // 
            // pBox01P1
            // 
            this.pBox01P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox01P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox01P1.Location = new System.Drawing.Point(3, 229);
            this.pBox01P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox01P1.Name = "pBox01P1";
            this.pBox01P1.Size = new System.Drawing.Size(44, 39);
            this.pBox01P1.TabIndex = 195;
            this.pBox01P1.TabStop = false;
            // 
            // pBox11P2
            // 
            this.pBox11P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox11P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox11P2.Location = new System.Drawing.Point(3, 185);
            this.pBox11P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox11P2.Name = "pBox11P2";
            this.pBox11P2.Size = new System.Drawing.Size(44, 39);
            this.pBox11P2.TabIndex = 196;
            this.pBox11P2.TabStop = false;
            // 
            // pBox11P0
            // 
            this.pBox11P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox11P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox11P0.Location = new System.Drawing.Point(3, 185);
            this.pBox11P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox11P0.Name = "pBox11P0";
            this.pBox11P0.Size = new System.Drawing.Size(44, 39);
            this.pBox11P0.TabIndex = 197;
            this.pBox11P0.TabStop = false;
            // 
            // pBox11P1
            // 
            this.pBox11P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox11P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox11P1.Location = new System.Drawing.Point(3, 185);
            this.pBox11P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox11P1.Name = "pBox11P1";
            this.pBox11P1.Size = new System.Drawing.Size(44, 39);
            this.pBox11P1.TabIndex = 198;
            this.pBox11P1.TabStop = false;
            // 
            // pBox21P2
            // 
            this.pBox21P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox21P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox21P2.Location = new System.Drawing.Point(3, 140);
            this.pBox21P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox21P2.Name = "pBox21P2";
            this.pBox21P2.Size = new System.Drawing.Size(44, 39);
            this.pBox21P2.TabIndex = 199;
            this.pBox21P2.TabStop = false;
            // 
            // pBox21P0
            // 
            this.pBox21P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox21P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox21P0.Location = new System.Drawing.Point(3, 140);
            this.pBox21P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox21P0.Name = "pBox21P0";
            this.pBox21P0.Size = new System.Drawing.Size(44, 39);
            this.pBox21P0.TabIndex = 200;
            this.pBox21P0.TabStop = false;
            // 
            // pBox21P1
            // 
            this.pBox21P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox21P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox21P1.Location = new System.Drawing.Point(3, 140);
            this.pBox21P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox21P1.Name = "pBox21P1";
            this.pBox21P1.Size = new System.Drawing.Size(44, 39);
            this.pBox21P1.TabIndex = 201;
            this.pBox21P1.TabStop = false;
            // 
            // pBox31P2
            // 
            this.pBox31P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox31P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox31P2.Location = new System.Drawing.Point(3, 95);
            this.pBox31P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox31P2.Name = "pBox31P2";
            this.pBox31P2.Size = new System.Drawing.Size(44, 39);
            this.pBox31P2.TabIndex = 202;
            this.pBox31P2.TabStop = false;
            // 
            // pBox31P0
            // 
            this.pBox31P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox31P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox31P0.Location = new System.Drawing.Point(3, 95);
            this.pBox31P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox31P0.Name = "pBox31P0";
            this.pBox31P0.Size = new System.Drawing.Size(44, 39);
            this.pBox31P0.TabIndex = 203;
            this.pBox31P0.TabStop = false;
            // 
            // pBox31P1
            // 
            this.pBox31P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox31P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox31P1.Location = new System.Drawing.Point(3, 95);
            this.pBox31P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox31P1.Name = "pBox31P1";
            this.pBox31P1.Size = new System.Drawing.Size(44, 39);
            this.pBox31P1.TabIndex = 204;
            this.pBox31P1.TabStop = false;
            // 
            // pBox41P2
            // 
            this.pBox41P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox41P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox41P2.Location = new System.Drawing.Point(3, 50);
            this.pBox41P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox41P2.Name = "pBox41P2";
            this.pBox41P2.Size = new System.Drawing.Size(44, 39);
            this.pBox41P2.TabIndex = 205;
            this.pBox41P2.TabStop = false;
            // 
            // pBox41P0
            // 
            this.pBox41P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox41P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox41P0.Location = new System.Drawing.Point(3, 50);
            this.pBox41P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox41P0.Name = "pBox41P0";
            this.pBox41P0.Size = new System.Drawing.Size(44, 39);
            this.pBox41P0.TabIndex = 206;
            this.pBox41P0.TabStop = false;
            // 
            // pBox41P1
            // 
            this.pBox41P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox41P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox41P1.Location = new System.Drawing.Point(3, 50);
            this.pBox41P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox41P1.Name = "pBox41P1";
            this.pBox41P1.Size = new System.Drawing.Size(44, 39);
            this.pBox41P1.TabIndex = 207;
            this.pBox41P1.TabStop = false;
            // 
            // pBox51P2
            // 
            this.pBox51P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox51P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox51P2.Location = new System.Drawing.Point(3, 6);
            this.pBox51P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox51P2.Name = "pBox51P2";
            this.pBox51P2.Size = new System.Drawing.Size(44, 39);
            this.pBox51P2.TabIndex = 208;
            this.pBox51P2.TabStop = false;
            // 
            // pBox51P0
            // 
            this.pBox51P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox51P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox51P0.Location = new System.Drawing.Point(3, 6);
            this.pBox51P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox51P0.Name = "pBox51P0";
            this.pBox51P0.Size = new System.Drawing.Size(44, 39);
            this.pBox51P0.TabIndex = 209;
            this.pBox51P0.TabStop = false;
            // 
            // col1Panel
            // 
            this.col1Panel.BackColor = System.Drawing.Color.LemonChiffon;
            this.col1Panel.Controls.Add(this.pBox02P1);
            this.col1Panel.Controls.Add(this.pBox02P2);
            this.col1Panel.Controls.Add(this.pBox02P0);
            this.col1Panel.Controls.Add(this.pBox12P2);
            this.col1Panel.Controls.Add(this.pBox12P0);
            this.col1Panel.Controls.Add(this.pBox12P1);
            this.col1Panel.Controls.Add(this.pBox22P2);
            this.col1Panel.Controls.Add(this.pBox22P0);
            this.col1Panel.Controls.Add(this.pBox22P1);
            this.col1Panel.Controls.Add(this.pBox32P2);
            this.col1Panel.Controls.Add(this.pBox32P0);
            this.col1Panel.Controls.Add(this.pBox32P1);
            this.col1Panel.Controls.Add(this.pBox42P2);
            this.col1Panel.Controls.Add(this.pBox42P0);
            this.col1Panel.Controls.Add(this.pBox42P1);
            this.col1Panel.Controls.Add(this.pBox52P2);
            this.col1Panel.Controls.Add(this.pBox52P0);
            this.col1Panel.Controls.Add(this.pBox52P1);
            this.col1Panel.Location = new System.Drawing.Point(157, 73);
            this.col1Panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.col1Panel.Name = "col1Panel";
            this.col1Panel.Size = new System.Drawing.Size(48, 289);
            this.col1Panel.TabIndex = 174;
            this.col1Panel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col2_MouseClick);
            this.col1Panel.MouseLeave += new System.EventHandler(this.col2_MouseLeave);
            this.col1Panel.MouseHover += new System.EventHandler(this.col2_MouseHover);
            // 
            // pBox02P1
            // 
            this.pBox02P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox02P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox02P1.Location = new System.Drawing.Point(3, 229);
            this.pBox02P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox02P1.Name = "pBox02P1";
            this.pBox02P1.Size = new System.Drawing.Size(44, 39);
            this.pBox02P1.TabIndex = 213;
            this.pBox02P1.TabStop = false;
            // 
            // pBox02P2
            // 
            this.pBox02P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox02P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox02P2.Location = new System.Drawing.Point(3, 229);
            this.pBox02P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox02P2.Name = "pBox02P2";
            this.pBox02P2.Size = new System.Drawing.Size(44, 39);
            this.pBox02P2.TabIndex = 211;
            this.pBox02P2.TabStop = false;
            // 
            // pBox02P0
            // 
            this.pBox02P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox02P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox02P0.Location = new System.Drawing.Point(3, 228);
            this.pBox02P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox02P0.Name = "pBox02P0";
            this.pBox02P0.Size = new System.Drawing.Size(44, 39);
            this.pBox02P0.TabIndex = 212;
            this.pBox02P0.TabStop = false;
            // 
            // pBox12P2
            // 
            this.pBox12P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox12P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox12P2.Location = new System.Drawing.Point(3, 185);
            this.pBox12P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox12P2.Name = "pBox12P2";
            this.pBox12P2.Size = new System.Drawing.Size(44, 39);
            this.pBox12P2.TabIndex = 214;
            this.pBox12P2.TabStop = false;
            // 
            // pBox12P0
            // 
            this.pBox12P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox12P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox12P0.Location = new System.Drawing.Point(3, 183);
            this.pBox12P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox12P0.Name = "pBox12P0";
            this.pBox12P0.Size = new System.Drawing.Size(44, 39);
            this.pBox12P0.TabIndex = 215;
            this.pBox12P0.TabStop = false;
            // 
            // pBox12P1
            // 
            this.pBox12P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox12P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox12P1.Location = new System.Drawing.Point(3, 185);
            this.pBox12P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox12P1.Name = "pBox12P1";
            this.pBox12P1.Size = new System.Drawing.Size(44, 39);
            this.pBox12P1.TabIndex = 216;
            this.pBox12P1.TabStop = false;
            // 
            // pBox22P2
            // 
            this.pBox22P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox22P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox22P2.Location = new System.Drawing.Point(3, 140);
            this.pBox22P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox22P2.Name = "pBox22P2";
            this.pBox22P2.Size = new System.Drawing.Size(44, 39);
            this.pBox22P2.TabIndex = 217;
            this.pBox22P2.TabStop = false;
            // 
            // pBox22P0
            // 
            this.pBox22P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox22P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox22P0.Location = new System.Drawing.Point(3, 139);
            this.pBox22P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox22P0.Name = "pBox22P0";
            this.pBox22P0.Size = new System.Drawing.Size(44, 39);
            this.pBox22P0.TabIndex = 218;
            this.pBox22P0.TabStop = false;
            // 
            // pBox22P1
            // 
            this.pBox22P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox22P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox22P1.Location = new System.Drawing.Point(3, 140);
            this.pBox22P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox22P1.Name = "pBox22P1";
            this.pBox22P1.Size = new System.Drawing.Size(44, 39);
            this.pBox22P1.TabIndex = 219;
            this.pBox22P1.TabStop = false;
            // 
            // pBox32P2
            // 
            this.pBox32P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox32P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox32P2.Location = new System.Drawing.Point(3, 95);
            this.pBox32P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox32P2.Name = "pBox32P2";
            this.pBox32P2.Size = new System.Drawing.Size(44, 39);
            this.pBox32P2.TabIndex = 220;
            this.pBox32P2.TabStop = false;
            // 
            // pBox32P0
            // 
            this.pBox32P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox32P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox32P0.Location = new System.Drawing.Point(3, 94);
            this.pBox32P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox32P0.Name = "pBox32P0";
            this.pBox32P0.Size = new System.Drawing.Size(44, 39);
            this.pBox32P0.TabIndex = 221;
            this.pBox32P0.TabStop = false;
            // 
            // pBox32P1
            // 
            this.pBox32P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox32P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox32P1.Location = new System.Drawing.Point(3, 95);
            this.pBox32P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox32P1.Name = "pBox32P1";
            this.pBox32P1.Size = new System.Drawing.Size(44, 39);
            this.pBox32P1.TabIndex = 222;
            this.pBox32P1.TabStop = false;
            // 
            // pBox42P2
            // 
            this.pBox42P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox42P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox42P2.Location = new System.Drawing.Point(3, 50);
            this.pBox42P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox42P2.Name = "pBox42P2";
            this.pBox42P2.Size = new System.Drawing.Size(44, 39);
            this.pBox42P2.TabIndex = 223;
            this.pBox42P2.TabStop = false;
            // 
            // pBox42P0
            // 
            this.pBox42P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox42P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox42P0.Location = new System.Drawing.Point(3, 49);
            this.pBox42P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox42P0.Name = "pBox42P0";
            this.pBox42P0.Size = new System.Drawing.Size(44, 39);
            this.pBox42P0.TabIndex = 224;
            this.pBox42P0.TabStop = false;
            // 
            // pBox42P1
            // 
            this.pBox42P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox42P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox42P1.Location = new System.Drawing.Point(3, 50);
            this.pBox42P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox42P1.Name = "pBox42P1";
            this.pBox42P1.Size = new System.Drawing.Size(44, 39);
            this.pBox42P1.TabIndex = 225;
            this.pBox42P1.TabStop = false;
            // 
            // pBox52P2
            // 
            this.pBox52P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox52P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox52P2.Location = new System.Drawing.Point(3, 6);
            this.pBox52P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox52P2.Name = "pBox52P2";
            this.pBox52P2.Size = new System.Drawing.Size(44, 39);
            this.pBox52P2.TabIndex = 226;
            this.pBox52P2.TabStop = false;
            // 
            // pBox52P0
            // 
            this.pBox52P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox52P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox52P0.Location = new System.Drawing.Point(3, 5);
            this.pBox52P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox52P0.Name = "pBox52P0";
            this.pBox52P0.Size = new System.Drawing.Size(44, 39);
            this.pBox52P0.TabIndex = 227;
            this.pBox52P0.TabStop = false;
            // 
            // pBox52P1
            // 
            this.pBox52P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox52P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox52P1.Location = new System.Drawing.Point(3, 6);
            this.pBox52P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox52P1.Name = "pBox52P1";
            this.pBox52P1.Size = new System.Drawing.Size(44, 39);
            this.pBox52P1.TabIndex = 228;
            this.pBox52P1.TabStop = false;
            // 
            // col2Panel
            // 
            this.col2Panel.BackColor = System.Drawing.Color.LemonChiffon;
            this.col2Panel.Controls.Add(this.pBox53P1);
            this.col2Panel.Controls.Add(this.pBox03P2);
            this.col2Panel.Controls.Add(this.pBox03P0);
            this.col2Panel.Controls.Add(this.pBox03P1);
            this.col2Panel.Controls.Add(this.pBox13P2);
            this.col2Panel.Controls.Add(this.pBox13P0);
            this.col2Panel.Controls.Add(this.pBox13P1);
            this.col2Panel.Controls.Add(this.pBox23P2);
            this.col2Panel.Controls.Add(this.pBox23P0);
            this.col2Panel.Controls.Add(this.pBox23P1);
            this.col2Panel.Controls.Add(this.pBox33P2);
            this.col2Panel.Controls.Add(this.pBox33P0);
            this.col2Panel.Controls.Add(this.pBox33P1);
            this.col2Panel.Controls.Add(this.pBox43P2);
            this.col2Panel.Controls.Add(this.pBox43P0);
            this.col2Panel.Controls.Add(this.pBox43P1);
            this.col2Panel.Controls.Add(this.pBox53P2);
            this.col2Panel.Controls.Add(this.pBox53P0);
            this.col2Panel.Location = new System.Drawing.Point(211, 73);
            this.col2Panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.col2Panel.Name = "col2Panel";
            this.col2Panel.Size = new System.Drawing.Size(48, 289);
            this.col2Panel.TabIndex = 175;
            this.col2Panel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col3_MouseClick);
            this.col2Panel.MouseLeave += new System.EventHandler(this.col3_MouseLeave);
            this.col2Panel.MouseHover += new System.EventHandler(this.col3_MouseHover);
            // 
            // pBox53P1
            // 
            this.pBox53P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox53P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox53P1.Location = new System.Drawing.Point(3, 6);
            this.pBox53P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox53P1.Name = "pBox53P1";
            this.pBox53P1.Size = new System.Drawing.Size(44, 39);
            this.pBox53P1.TabIndex = 282;
            this.pBox53P1.TabStop = false;
            // 
            // pBox03P2
            // 
            this.pBox03P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox03P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox03P2.Location = new System.Drawing.Point(3, 229);
            this.pBox03P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox03P2.Name = "pBox03P2";
            this.pBox03P2.Size = new System.Drawing.Size(44, 39);
            this.pBox03P2.TabIndex = 265;
            this.pBox03P2.TabStop = false;
            // 
            // pBox03P0
            // 
            this.pBox03P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox03P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox03P0.Location = new System.Drawing.Point(3, 229);
            this.pBox03P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox03P0.Name = "pBox03P0";
            this.pBox03P0.Size = new System.Drawing.Size(44, 39);
            this.pBox03P0.TabIndex = 266;
            this.pBox03P0.TabStop = false;
            // 
            // pBox03P1
            // 
            this.pBox03P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox03P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox03P1.Location = new System.Drawing.Point(3, 229);
            this.pBox03P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox03P1.Name = "pBox03P1";
            this.pBox03P1.Size = new System.Drawing.Size(44, 39);
            this.pBox03P1.TabIndex = 267;
            this.pBox03P1.TabStop = false;
            // 
            // pBox13P2
            // 
            this.pBox13P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox13P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox13P2.Location = new System.Drawing.Point(3, 185);
            this.pBox13P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox13P2.Name = "pBox13P2";
            this.pBox13P2.Size = new System.Drawing.Size(44, 39);
            this.pBox13P2.TabIndex = 268;
            this.pBox13P2.TabStop = false;
            // 
            // pBox13P0
            // 
            this.pBox13P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox13P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox13P0.Location = new System.Drawing.Point(3, 185);
            this.pBox13P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox13P0.Name = "pBox13P0";
            this.pBox13P0.Size = new System.Drawing.Size(44, 39);
            this.pBox13P0.TabIndex = 269;
            this.pBox13P0.TabStop = false;
            // 
            // pBox13P1
            // 
            this.pBox13P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox13P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox13P1.Location = new System.Drawing.Point(3, 185);
            this.pBox13P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox13P1.Name = "pBox13P1";
            this.pBox13P1.Size = new System.Drawing.Size(44, 39);
            this.pBox13P1.TabIndex = 270;
            this.pBox13P1.TabStop = false;
            // 
            // pBox23P2
            // 
            this.pBox23P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox23P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox23P2.Location = new System.Drawing.Point(3, 140);
            this.pBox23P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox23P2.Name = "pBox23P2";
            this.pBox23P2.Size = new System.Drawing.Size(44, 39);
            this.pBox23P2.TabIndex = 271;
            this.pBox23P2.TabStop = false;
            // 
            // pBox23P0
            // 
            this.pBox23P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox23P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox23P0.Location = new System.Drawing.Point(3, 140);
            this.pBox23P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox23P0.Name = "pBox23P0";
            this.pBox23P0.Size = new System.Drawing.Size(44, 39);
            this.pBox23P0.TabIndex = 272;
            this.pBox23P0.TabStop = false;
            // 
            // pBox23P1
            // 
            this.pBox23P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox23P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox23P1.Location = new System.Drawing.Point(3, 140);
            this.pBox23P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox23P1.Name = "pBox23P1";
            this.pBox23P1.Size = new System.Drawing.Size(44, 39);
            this.pBox23P1.TabIndex = 273;
            this.pBox23P1.TabStop = false;
            // 
            // pBox33P2
            // 
            this.pBox33P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox33P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox33P2.Location = new System.Drawing.Point(3, 95);
            this.pBox33P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox33P2.Name = "pBox33P2";
            this.pBox33P2.Size = new System.Drawing.Size(44, 39);
            this.pBox33P2.TabIndex = 274;
            this.pBox33P2.TabStop = false;
            // 
            // pBox33P0
            // 
            this.pBox33P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox33P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox33P0.Location = new System.Drawing.Point(3, 95);
            this.pBox33P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox33P0.Name = "pBox33P0";
            this.pBox33P0.Size = new System.Drawing.Size(44, 39);
            this.pBox33P0.TabIndex = 275;
            this.pBox33P0.TabStop = false;
            // 
            // pBox33P1
            // 
            this.pBox33P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox33P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox33P1.Location = new System.Drawing.Point(3, 95);
            this.pBox33P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox33P1.Name = "pBox33P1";
            this.pBox33P1.Size = new System.Drawing.Size(44, 39);
            this.pBox33P1.TabIndex = 276;
            this.pBox33P1.TabStop = false;
            // 
            // pBox43P2
            // 
            this.pBox43P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox43P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox43P2.Location = new System.Drawing.Point(3, 50);
            this.pBox43P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox43P2.Name = "pBox43P2";
            this.pBox43P2.Size = new System.Drawing.Size(44, 39);
            this.pBox43P2.TabIndex = 277;
            this.pBox43P2.TabStop = false;
            // 
            // pBox43P0
            // 
            this.pBox43P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox43P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox43P0.Location = new System.Drawing.Point(3, 50);
            this.pBox43P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox43P0.Name = "pBox43P0";
            this.pBox43P0.Size = new System.Drawing.Size(44, 39);
            this.pBox43P0.TabIndex = 278;
            this.pBox43P0.TabStop = false;
            // 
            // pBox43P1
            // 
            this.pBox43P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox43P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox43P1.Location = new System.Drawing.Point(3, 50);
            this.pBox43P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox43P1.Name = "pBox43P1";
            this.pBox43P1.Size = new System.Drawing.Size(44, 39);
            this.pBox43P1.TabIndex = 279;
            this.pBox43P1.TabStop = false;
            // 
            // pBox53P2
            // 
            this.pBox53P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox53P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox53P2.Location = new System.Drawing.Point(3, 6);
            this.pBox53P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox53P2.Name = "pBox53P2";
            this.pBox53P2.Size = new System.Drawing.Size(44, 39);
            this.pBox53P2.TabIndex = 280;
            this.pBox53P2.TabStop = false;
            // 
            // pBox53P0
            // 
            this.pBox53P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox53P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox53P0.Location = new System.Drawing.Point(3, 6);
            this.pBox53P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox53P0.Name = "pBox53P0";
            this.pBox53P0.Size = new System.Drawing.Size(44, 39);
            this.pBox53P0.TabIndex = 281;
            this.pBox53P0.TabStop = false;
            // 
            // col3Panel
            // 
            this.col3Panel.BackColor = System.Drawing.Color.LemonChiffon;
            this.col3Panel.Controls.Add(this.pBox54P1);
            this.col3Panel.Controls.Add(this.pBox04P0);
            this.col3Panel.Controls.Add(this.pBox04P1);
            this.col3Panel.Controls.Add(this.pBox14P2);
            this.col3Panel.Controls.Add(this.pBox14P0);
            this.col3Panel.Controls.Add(this.pBox14P1);
            this.col3Panel.Controls.Add(this.pBox24P2);
            this.col3Panel.Controls.Add(this.pBox24P0);
            this.col3Panel.Controls.Add(this.pBox24P1);
            this.col3Panel.Controls.Add(this.pBox34P2);
            this.col3Panel.Controls.Add(this.pBox34P0);
            this.col3Panel.Controls.Add(this.pBox34P1);
            this.col3Panel.Controls.Add(this.pBox44P2);
            this.col3Panel.Controls.Add(this.pBox44P0);
            this.col3Panel.Controls.Add(this.pBox44P1);
            this.col3Panel.Controls.Add(this.pBox54P2);
            this.col3Panel.Controls.Add(this.pBox54P0);
            this.col3Panel.Controls.Add(this.pBox04P2);
            this.col3Panel.Location = new System.Drawing.Point(263, 73);
            this.col3Panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.col3Panel.Name = "col3Panel";
            this.col3Panel.Size = new System.Drawing.Size(48, 289);
            this.col3Panel.TabIndex = 176;
            this.col3Panel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col4_MouseClick);
            this.col3Panel.MouseLeave += new System.EventHandler(this.col4_MouseLeave);
            this.col3Panel.MouseHover += new System.EventHandler(this.col4_MouseHover);
            // 
            // pBox54P1
            // 
            this.pBox54P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox54P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox54P1.Location = new System.Drawing.Point(3, 6);
            this.pBox54P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox54P1.Name = "pBox54P1";
            this.pBox54P1.Size = new System.Drawing.Size(44, 39);
            this.pBox54P1.TabIndex = 246;
            this.pBox54P1.TabStop = false;
            // 
            // pBox04P0
            // 
            this.pBox04P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox04P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox04P0.Location = new System.Drawing.Point(3, 230);
            this.pBox04P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox04P0.Name = "pBox04P0";
            this.pBox04P0.Size = new System.Drawing.Size(44, 39);
            this.pBox04P0.TabIndex = 230;
            this.pBox04P0.TabStop = false;
            // 
            // pBox04P1
            // 
            this.pBox04P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox04P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox04P1.Location = new System.Drawing.Point(3, 229);
            this.pBox04P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox04P1.Name = "pBox04P1";
            this.pBox04P1.Size = new System.Drawing.Size(44, 39);
            this.pBox04P1.TabIndex = 231;
            this.pBox04P1.TabStop = false;
            // 
            // pBox14P2
            // 
            this.pBox14P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox14P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox14P2.Location = new System.Drawing.Point(3, 186);
            this.pBox14P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox14P2.Name = "pBox14P2";
            this.pBox14P2.Size = new System.Drawing.Size(44, 39);
            this.pBox14P2.TabIndex = 232;
            this.pBox14P2.TabStop = false;
            // 
            // pBox14P0
            // 
            this.pBox14P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox14P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox14P0.Location = new System.Drawing.Point(3, 186);
            this.pBox14P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox14P0.Name = "pBox14P0";
            this.pBox14P0.Size = new System.Drawing.Size(44, 39);
            this.pBox14P0.TabIndex = 233;
            this.pBox14P0.TabStop = false;
            // 
            // pBox14P1
            // 
            this.pBox14P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox14P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox14P1.Location = new System.Drawing.Point(3, 185);
            this.pBox14P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox14P1.Name = "pBox14P1";
            this.pBox14P1.Size = new System.Drawing.Size(44, 39);
            this.pBox14P1.TabIndex = 234;
            this.pBox14P1.TabStop = false;
            // 
            // pBox24P2
            // 
            this.pBox24P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox24P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox24P2.Location = new System.Drawing.Point(3, 142);
            this.pBox24P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox24P2.Name = "pBox24P2";
            this.pBox24P2.Size = new System.Drawing.Size(44, 39);
            this.pBox24P2.TabIndex = 235;
            this.pBox24P2.TabStop = false;
            // 
            // pBox24P0
            // 
            this.pBox24P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox24P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox24P0.Location = new System.Drawing.Point(3, 142);
            this.pBox24P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox24P0.Name = "pBox24P0";
            this.pBox24P0.Size = new System.Drawing.Size(44, 39);
            this.pBox24P0.TabIndex = 236;
            this.pBox24P0.TabStop = false;
            // 
            // pBox24P1
            // 
            this.pBox24P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox24P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox24P1.Location = new System.Drawing.Point(3, 140);
            this.pBox24P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox24P1.Name = "pBox24P1";
            this.pBox24P1.Size = new System.Drawing.Size(44, 39);
            this.pBox24P1.TabIndex = 237;
            this.pBox24P1.TabStop = false;
            // 
            // pBox34P2
            // 
            this.pBox34P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox34P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox34P2.Location = new System.Drawing.Point(3, 96);
            this.pBox34P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox34P2.Name = "pBox34P2";
            this.pBox34P2.Size = new System.Drawing.Size(44, 39);
            this.pBox34P2.TabIndex = 238;
            this.pBox34P2.TabStop = false;
            // 
            // pBox34P0
            // 
            this.pBox34P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox34P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox34P0.Location = new System.Drawing.Point(3, 96);
            this.pBox34P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox34P0.Name = "pBox34P0";
            this.pBox34P0.Size = new System.Drawing.Size(44, 39);
            this.pBox34P0.TabIndex = 239;
            this.pBox34P0.TabStop = false;
            // 
            // pBox34P1
            // 
            this.pBox34P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox34P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox34P1.Location = new System.Drawing.Point(3, 95);
            this.pBox34P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox34P1.Name = "pBox34P1";
            this.pBox34P1.Size = new System.Drawing.Size(44, 39);
            this.pBox34P1.TabIndex = 240;
            this.pBox34P1.TabStop = false;
            // 
            // pBox44P2
            // 
            this.pBox44P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox44P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox44P2.Location = new System.Drawing.Point(3, 52);
            this.pBox44P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox44P2.Name = "pBox44P2";
            this.pBox44P2.Size = new System.Drawing.Size(44, 39);
            this.pBox44P2.TabIndex = 241;
            this.pBox44P2.TabStop = false;
            // 
            // pBox44P0
            // 
            this.pBox44P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox44P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox44P0.Location = new System.Drawing.Point(3, 52);
            this.pBox44P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox44P0.Name = "pBox44P0";
            this.pBox44P0.Size = new System.Drawing.Size(44, 39);
            this.pBox44P0.TabIndex = 242;
            this.pBox44P0.TabStop = false;
            // 
            // pBox44P1
            // 
            this.pBox44P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox44P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox44P1.Location = new System.Drawing.Point(3, 50);
            this.pBox44P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox44P1.Name = "pBox44P1";
            this.pBox44P1.Size = new System.Drawing.Size(44, 39);
            this.pBox44P1.TabIndex = 243;
            this.pBox44P1.TabStop = false;
            // 
            // pBox54P2
            // 
            this.pBox54P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox54P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox54P2.Location = new System.Drawing.Point(3, 7);
            this.pBox54P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox54P2.Name = "pBox54P2";
            this.pBox54P2.Size = new System.Drawing.Size(44, 39);
            this.pBox54P2.TabIndex = 244;
            this.pBox54P2.TabStop = false;
            // 
            // pBox54P0
            // 
            this.pBox54P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox54P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox54P0.Location = new System.Drawing.Point(3, 7);
            this.pBox54P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox54P0.Name = "pBox54P0";
            this.pBox54P0.Size = new System.Drawing.Size(44, 39);
            this.pBox54P0.TabIndex = 245;
            this.pBox54P0.TabStop = false;
            // 
            // pBox04P2
            // 
            this.pBox04P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox04P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox04P2.Location = new System.Drawing.Point(3, 230);
            this.pBox04P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox04P2.Name = "pBox04P2";
            this.pBox04P2.Size = new System.Drawing.Size(44, 39);
            this.pBox04P2.TabIndex = 229;
            this.pBox04P2.TabStop = false;
            // 
            // col4Panel
            // 
            this.col4Panel.BackColor = System.Drawing.Color.LemonChiffon;
            this.col4Panel.Controls.Add(this.pBox55P1);
            this.col4Panel.Controls.Add(this.pBox05P2);
            this.col4Panel.Controls.Add(this.pBox05P0);
            this.col4Panel.Controls.Add(this.pBox05P1);
            this.col4Panel.Controls.Add(this.pBox15P2);
            this.col4Panel.Controls.Add(this.pBox15P0);
            this.col4Panel.Controls.Add(this.pBox15P1);
            this.col4Panel.Controls.Add(this.pBox25P2);
            this.col4Panel.Controls.Add(this.pBox25P0);
            this.col4Panel.Controls.Add(this.pBox25P1);
            this.col4Panel.Controls.Add(this.pBox35P2);
            this.col4Panel.Controls.Add(this.pBox35P0);
            this.col4Panel.Controls.Add(this.pBox35P1);
            this.col4Panel.Controls.Add(this.pBox45P2);
            this.col4Panel.Controls.Add(this.pBox45P0);
            this.col4Panel.Controls.Add(this.pBox45P1);
            this.col4Panel.Controls.Add(this.pBox55P2);
            this.col4Panel.Controls.Add(this.pBox55P0);
            this.col4Panel.Location = new System.Drawing.Point(316, 73);
            this.col4Panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.col4Panel.Name = "col4Panel";
            this.col4Panel.Size = new System.Drawing.Size(48, 289);
            this.col4Panel.TabIndex = 177;
            this.col4Panel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col5_MouseClick);
            this.col4Panel.MouseLeave += new System.EventHandler(this.col5_MouseLeave);
            this.col4Panel.MouseHover += new System.EventHandler(this.col5_MouseHover);
            // 
            // pBox55P1
            // 
            this.pBox55P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox55P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox55P1.Location = new System.Drawing.Point(1, 6);
            this.pBox55P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox55P1.Name = "pBox55P1";
            this.pBox55P1.Size = new System.Drawing.Size(44, 39);
            this.pBox55P1.TabIndex = 264;
            this.pBox55P1.TabStop = false;
            // 
            // pBox05P2
            // 
            this.pBox05P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox05P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox05P2.Location = new System.Drawing.Point(1, 230);
            this.pBox05P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox05P2.Name = "pBox05P2";
            this.pBox05P2.Size = new System.Drawing.Size(44, 39);
            this.pBox05P2.TabIndex = 247;
            this.pBox05P2.TabStop = false;
            // 
            // pBox05P0
            // 
            this.pBox05P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox05P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox05P0.Location = new System.Drawing.Point(1, 230);
            this.pBox05P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox05P0.Name = "pBox05P0";
            this.pBox05P0.Size = new System.Drawing.Size(44, 39);
            this.pBox05P0.TabIndex = 248;
            this.pBox05P0.TabStop = false;
            // 
            // pBox05P1
            // 
            this.pBox05P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox05P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox05P1.Location = new System.Drawing.Point(1, 229);
            this.pBox05P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox05P1.Name = "pBox05P1";
            this.pBox05P1.Size = new System.Drawing.Size(44, 39);
            this.pBox05P1.TabIndex = 249;
            this.pBox05P1.TabStop = false;
            // 
            // pBox15P2
            // 
            this.pBox15P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox15P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox15P2.Location = new System.Drawing.Point(1, 186);
            this.pBox15P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox15P2.Name = "pBox15P2";
            this.pBox15P2.Size = new System.Drawing.Size(44, 39);
            this.pBox15P2.TabIndex = 250;
            this.pBox15P2.TabStop = false;
            // 
            // pBox15P0
            // 
            this.pBox15P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox15P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox15P0.Location = new System.Drawing.Point(1, 186);
            this.pBox15P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox15P0.Name = "pBox15P0";
            this.pBox15P0.Size = new System.Drawing.Size(44, 39);
            this.pBox15P0.TabIndex = 251;
            this.pBox15P0.TabStop = false;
            // 
            // pBox15P1
            // 
            this.pBox15P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox15P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox15P1.Location = new System.Drawing.Point(1, 185);
            this.pBox15P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox15P1.Name = "pBox15P1";
            this.pBox15P1.Size = new System.Drawing.Size(44, 39);
            this.pBox15P1.TabIndex = 252;
            this.pBox15P1.TabStop = false;
            // 
            // pBox25P2
            // 
            this.pBox25P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox25P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox25P2.Location = new System.Drawing.Point(1, 142);
            this.pBox25P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox25P2.Name = "pBox25P2";
            this.pBox25P2.Size = new System.Drawing.Size(44, 39);
            this.pBox25P2.TabIndex = 253;
            this.pBox25P2.TabStop = false;
            // 
            // pBox25P0
            // 
            this.pBox25P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox25P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox25P0.Location = new System.Drawing.Point(1, 142);
            this.pBox25P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox25P0.Name = "pBox25P0";
            this.pBox25P0.Size = new System.Drawing.Size(44, 39);
            this.pBox25P0.TabIndex = 254;
            this.pBox25P0.TabStop = false;
            // 
            // pBox25P1
            // 
            this.pBox25P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox25P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox25P1.Location = new System.Drawing.Point(1, 140);
            this.pBox25P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox25P1.Name = "pBox25P1";
            this.pBox25P1.Size = new System.Drawing.Size(44, 39);
            this.pBox25P1.TabIndex = 255;
            this.pBox25P1.TabStop = false;
            // 
            // pBox35P2
            // 
            this.pBox35P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox35P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox35P2.Location = new System.Drawing.Point(1, 96);
            this.pBox35P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox35P2.Name = "pBox35P2";
            this.pBox35P2.Size = new System.Drawing.Size(44, 39);
            this.pBox35P2.TabIndex = 256;
            this.pBox35P2.TabStop = false;
            // 
            // pBox35P0
            // 
            this.pBox35P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox35P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox35P0.Location = new System.Drawing.Point(1, 96);
            this.pBox35P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox35P0.Name = "pBox35P0";
            this.pBox35P0.Size = new System.Drawing.Size(44, 39);
            this.pBox35P0.TabIndex = 257;
            this.pBox35P0.TabStop = false;
            // 
            // pBox35P1
            // 
            this.pBox35P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox35P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox35P1.Location = new System.Drawing.Point(1, 95);
            this.pBox35P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox35P1.Name = "pBox35P1";
            this.pBox35P1.Size = new System.Drawing.Size(44, 39);
            this.pBox35P1.TabIndex = 258;
            this.pBox35P1.TabStop = false;
            // 
            // pBox45P2
            // 
            this.pBox45P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox45P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox45P2.Location = new System.Drawing.Point(1, 52);
            this.pBox45P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox45P2.Name = "pBox45P2";
            this.pBox45P2.Size = new System.Drawing.Size(44, 39);
            this.pBox45P2.TabIndex = 259;
            this.pBox45P2.TabStop = false;
            // 
            // pBox45P0
            // 
            this.pBox45P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox45P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox45P0.Location = new System.Drawing.Point(1, 52);
            this.pBox45P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox45P0.Name = "pBox45P0";
            this.pBox45P0.Size = new System.Drawing.Size(44, 39);
            this.pBox45P0.TabIndex = 260;
            this.pBox45P0.TabStop = false;
            // 
            // pBox45P1
            // 
            this.pBox45P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox45P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox45P1.Location = new System.Drawing.Point(1, 50);
            this.pBox45P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox45P1.Name = "pBox45P1";
            this.pBox45P1.Size = new System.Drawing.Size(44, 39);
            this.pBox45P1.TabIndex = 261;
            this.pBox45P1.TabStop = false;
            // 
            // pBox55P2
            // 
            this.pBox55P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox55P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox55P2.Location = new System.Drawing.Point(1, 7);
            this.pBox55P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox55P2.Name = "pBox55P2";
            this.pBox55P2.Size = new System.Drawing.Size(44, 39);
            this.pBox55P2.TabIndex = 262;
            this.pBox55P2.TabStop = false;
            // 
            // pBox55P0
            // 
            this.pBox55P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox55P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox55P0.Location = new System.Drawing.Point(1, 7);
            this.pBox55P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox55P0.Name = "pBox55P0";
            this.pBox55P0.Size = new System.Drawing.Size(44, 39);
            this.pBox55P0.TabIndex = 263;
            this.pBox55P0.TabStop = false;
            // 
            // pBox40P2
            // 
            this.pBox40P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox40P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox40P2.Location = new System.Drawing.Point(3, 48);
            this.pBox40P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox40P2.Name = "pBox40P2";
            this.pBox40P2.Size = new System.Drawing.Size(44, 39);
            this.pBox40P2.TabIndex = 20;
            this.pBox40P2.TabStop = false;
            this.pBox40P2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox40P2.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox40P2.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox40P1
            // 
            this.pBox40P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox40P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox40P1.Location = new System.Drawing.Point(3, 48);
            this.pBox40P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox40P1.Name = "pBox40P1";
            this.pBox40P1.Size = new System.Drawing.Size(44, 39);
            this.pBox40P1.TabIndex = 22;
            this.pBox40P1.TabStop = false;
            this.pBox40P1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox40P1.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox40P1.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox30P2
            // 
            this.pBox30P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox30P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox30P2.Location = new System.Drawing.Point(3, 94);
            this.pBox30P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox30P2.Name = "pBox30P2";
            this.pBox30P2.Size = new System.Drawing.Size(44, 39);
            this.pBox30P2.TabIndex = 17;
            this.pBox30P2.TabStop = false;
            this.pBox30P2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox30P2.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox30P2.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox20P2
            // 
            this.pBox20P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox20P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox20P2.Location = new System.Drawing.Point(3, 138);
            this.pBox20P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox20P2.Name = "pBox20P2";
            this.pBox20P2.Size = new System.Drawing.Size(44, 39);
            this.pBox20P2.TabIndex = 14;
            this.pBox20P2.TabStop = false;
            this.pBox20P2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox20P2.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox20P2.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox20P1
            // 
            this.pBox20P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox20P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox20P1.Location = new System.Drawing.Point(3, 139);
            this.pBox20P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox20P1.Name = "pBox20P1";
            this.pBox20P1.Size = new System.Drawing.Size(44, 39);
            this.pBox20P1.TabIndex = 16;
            this.pBox20P1.TabStop = false;
            this.pBox20P1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox20P1.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox20P1.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox40P0
            // 
            this.pBox40P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox40P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox40P0.Location = new System.Drawing.Point(3, 48);
            this.pBox40P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox40P0.Name = "pBox40P0";
            this.pBox40P0.Size = new System.Drawing.Size(44, 39);
            this.pBox40P0.TabIndex = 21;
            this.pBox40P0.TabStop = false;
            this.pBox40P0.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox40P0.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox40P0.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox30P1
            // 
            this.pBox30P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox30P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox30P1.Location = new System.Drawing.Point(3, 95);
            this.pBox30P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox30P1.Name = "pBox30P1";
            this.pBox30P1.Size = new System.Drawing.Size(44, 39);
            this.pBox30P1.TabIndex = 19;
            this.pBox30P1.TabStop = false;
            this.pBox30P1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox30P1.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox30P1.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox30P0
            // 
            this.pBox30P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox30P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox30P0.Location = new System.Drawing.Point(3, 95);
            this.pBox30P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox30P0.Name = "pBox30P0";
            this.pBox30P0.Size = new System.Drawing.Size(44, 39);
            this.pBox30P0.TabIndex = 18;
            this.pBox30P0.TabStop = false;
            this.pBox30P0.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox30P0.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox30P0.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox20P0
            // 
            this.pBox20P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox20P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox20P0.Location = new System.Drawing.Point(3, 139);
            this.pBox20P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox20P0.Name = "pBox20P0";
            this.pBox20P0.Size = new System.Drawing.Size(44, 39);
            this.pBox20P0.TabIndex = 15;
            this.pBox20P0.TabStop = false;
            this.pBox20P0.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox20P0.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox20P0.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox10P2
            // 
            this.pBox10P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox10P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox10P2.Location = new System.Drawing.Point(3, 183);
            this.pBox10P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox10P2.Name = "pBox10P2";
            this.pBox10P2.Size = new System.Drawing.Size(44, 39);
            this.pBox10P2.TabIndex = 11;
            this.pBox10P2.TabStop = false;
            this.pBox10P2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox10P2.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox10P2.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox10P1
            // 
            this.pBox10P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox10P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox10P1.Location = new System.Drawing.Point(3, 185);
            this.pBox10P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox10P1.Name = "pBox10P1";
            this.pBox10P1.Size = new System.Drawing.Size(44, 39);
            this.pBox10P1.TabIndex = 13;
            this.pBox10P1.TabStop = false;
            this.pBox10P1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox10P1.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox10P1.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox10P0
            // 
            this.pBox10P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox10P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox10P0.Location = new System.Drawing.Point(3, 185);
            this.pBox10P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox10P0.Name = "pBox10P0";
            this.pBox10P0.Size = new System.Drawing.Size(44, 39);
            this.pBox10P0.TabIndex = 12;
            this.pBox10P0.TabStop = false;
            this.pBox10P0.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox10P0.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox10P0.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox00P1
            // 
            this.pBox00P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox00P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox00P1.Location = new System.Drawing.Point(3, 230);
            this.pBox00P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox00P1.Name = "pBox00P1";
            this.pBox00P1.Size = new System.Drawing.Size(44, 39);
            this.pBox00P1.TabIndex = 10;
            this.pBox00P1.TabStop = false;
            this.pBox00P1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox00P1.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox00P1.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox00P0
            // 
            this.pBox00P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox00P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox00P0.Location = new System.Drawing.Point(3, 229);
            this.pBox00P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox00P0.Name = "pBox00P0";
            this.pBox00P0.Size = new System.Drawing.Size(44, 39);
            this.pBox00P0.TabIndex = 9;
            this.pBox00P0.TabStop = false;
            this.pBox00P0.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox00P0.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox00P0.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox50P0
            // 
            this.pBox50P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox50P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox50P0.Location = new System.Drawing.Point(3, 2);
            this.pBox50P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox50P0.Name = "pBox50P0";
            this.pBox50P0.Size = new System.Drawing.Size(44, 39);
            this.pBox50P0.TabIndex = 6;
            this.pBox50P0.TabStop = false;
            this.pBox50P0.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox50P0.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            this.pBox50P0.MouseHover += new System.EventHandler(this.col0_MouseHover);
            this.pBox50P0.MouseUp += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            // 
            // pBox50P2
            // 
            this.pBox50P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox50P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox50P2.Location = new System.Drawing.Point(3, 2);
            this.pBox50P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox50P2.Name = "pBox50P2";
            this.pBox50P2.Size = new System.Drawing.Size(44, 39);
            this.pBox50P2.TabIndex = 1;
            this.pBox50P2.TabStop = false;
            this.pBox50P2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox50P2.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            this.pBox50P2.MouseHover += new System.EventHandler(this.col0_MouseHover);
            this.pBox50P2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            // 
            // pBox00P2
            // 
            this.pBox00P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox00P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox00P2.Location = new System.Drawing.Point(3, 230);
            this.pBox00P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox00P2.Name = "pBox00P2";
            this.pBox00P2.Size = new System.Drawing.Size(44, 39);
            this.pBox00P2.TabIndex = 8;
            this.pBox00P2.TabStop = false;
            this.pBox00P2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox00P2.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.pBox00P2.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // pBox50P1
            // 
            this.pBox50P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox50P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox50P1.Location = new System.Drawing.Point(3, 4);
            this.pBox50P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox50P1.Name = "pBox50P1";
            this.pBox50P1.Size = new System.Drawing.Size(44, 39);
            this.pBox50P1.TabIndex = 7;
            this.pBox50P1.TabStop = false;
            this.pBox50P1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.pBox50P1.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            this.pBox50P1.MouseHover += new System.EventHandler(this.col0_MouseHover);
            // 
            // col0
            // 
            this.col0.BackColor = System.Drawing.Color.LemonChiffon;
            this.col0.Controls.Add(this.pBox50P1);
            this.col0.Controls.Add(this.pBox50P0);
            this.col0.Controls.Add(this.pBox00P1);
            this.col0.Controls.Add(this.pBox50P2);
            this.col0.Controls.Add(this.pBox00P0);
            this.col0.Controls.Add(this.pBox40P0);
            this.col0.Controls.Add(this.pBox10P2);
            this.col0.Controls.Add(this.pBox30P0);
            this.col0.Controls.Add(this.pBox00P2);
            this.col0.Controls.Add(this.pBox20P0);
            this.col0.Controls.Add(this.pBox20P2);
            this.col0.Controls.Add(this.pBox40P1);
            this.col0.Controls.Add(this.pBox10P1);
            this.col0.Controls.Add(this.pBox10P0);
            this.col0.Controls.Add(this.pBox30P2);
            this.col0.Controls.Add(this.pBox20P1);
            this.col0.Controls.Add(this.pBox30P1);
            this.col0.Controls.Add(this.pBox40P2);
            this.col0.Location = new System.Drawing.Point(51, 73);
            this.col0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.col0.Name = "col0";
            this.col0.Size = new System.Drawing.Size(48, 289);
            this.col0.TabIndex = 168;
            this.col0.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.col0.MouseEnter += new System.EventHandler(this.col0_MouseHover);
            this.col0.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            // 
            // col5Panel
            // 
            this.col5Panel.BackColor = System.Drawing.Color.LemonChiffon;
            this.col5Panel.Controls.Add(this.pBox56P1);
            this.col5Panel.Controls.Add(this.pBox06P1);
            this.col5Panel.Controls.Add(this.pBox16P1);
            this.col5Panel.Controls.Add(this.pBox26P1);
            this.col5Panel.Controls.Add(this.pBox36P1);
            this.col5Panel.Controls.Add(this.pBox46P1);
            this.col5Panel.Controls.Add(this.pBox56P2);
            this.col5Panel.Controls.Add(this.pBox06P2);
            this.col5Panel.Controls.Add(this.pBox16P2);
            this.col5Panel.Controls.Add(this.pBox26P2);
            this.col5Panel.Controls.Add(this.pBox36P2);
            this.col5Panel.Controls.Add(this.pBox46P2);
            this.col5Panel.Controls.Add(this.pBox06P0);
            this.col5Panel.Controls.Add(this.pBox16P0);
            this.col5Panel.Controls.Add(this.pBox26P0);
            this.col5Panel.Controls.Add(this.pBox36P0);
            this.col5Panel.Controls.Add(this.pBox46P0);
            this.col5Panel.Controls.Add(this.pBox56P0);
            this.col5Panel.Location = new System.Drawing.Point(369, 73);
            this.col5Panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.col5Panel.Name = "col5Panel";
            this.col5Panel.Size = new System.Drawing.Size(48, 289);
            this.col5Panel.TabIndex = 169;
            // 
            // pBox56P1
            // 
            this.pBox56P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox56P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox56P1.Location = new System.Drawing.Point(3, 7);
            this.pBox56P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox56P1.Name = "pBox56P1";
            this.pBox56P1.Size = new System.Drawing.Size(44, 39);
            this.pBox56P1.TabIndex = 192;
            this.pBox56P1.TabStop = false;
            // 
            // pBox06P1
            // 
            this.pBox06P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox06P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox06P1.Location = new System.Drawing.Point(3, 230);
            this.pBox06P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox06P1.Name = "pBox06P1";
            this.pBox06P1.Size = new System.Drawing.Size(44, 39);
            this.pBox06P1.TabIndex = 7;
            this.pBox06P1.TabStop = false;
            // 
            // pBox16P1
            // 
            this.pBox16P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox16P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox16P1.Location = new System.Drawing.Point(3, 186);
            this.pBox16P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox16P1.Name = "pBox16P1";
            this.pBox16P1.Size = new System.Drawing.Size(44, 39);
            this.pBox16P1.TabIndex = 180;
            this.pBox16P1.TabStop = false;
            // 
            // pBox26P1
            // 
            this.pBox26P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox26P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox26P1.Location = new System.Drawing.Point(3, 142);
            this.pBox26P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox26P1.Name = "pBox26P1";
            this.pBox26P1.Size = new System.Drawing.Size(44, 39);
            this.pBox26P1.TabIndex = 183;
            this.pBox26P1.TabStop = false;
            // 
            // pBox36P1
            // 
            this.pBox36P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox36P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox36P1.Location = new System.Drawing.Point(3, 96);
            this.pBox36P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox36P1.Name = "pBox36P1";
            this.pBox36P1.Size = new System.Drawing.Size(44, 39);
            this.pBox36P1.TabIndex = 186;
            this.pBox36P1.TabStop = false;
            // 
            // pBox46P1
            // 
            this.pBox46P1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBox46P1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox46P1.Location = new System.Drawing.Point(3, 52);
            this.pBox46P1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox46P1.Name = "pBox46P1";
            this.pBox46P1.Size = new System.Drawing.Size(44, 39);
            this.pBox46P1.TabIndex = 189;
            this.pBox46P1.TabStop = false;
            // 
            // pBox56P2
            // 
            this.pBox56P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox56P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox56P2.Location = new System.Drawing.Point(1, 9);
            this.pBox56P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox56P2.Name = "pBox56P2";
            this.pBox56P2.Size = new System.Drawing.Size(44, 39);
            this.pBox56P2.TabIndex = 190;
            this.pBox56P2.TabStop = false;
            // 
            // pBox06P2
            // 
            this.pBox06P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox06P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox06P2.Location = new System.Drawing.Point(1, 231);
            this.pBox06P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox06P2.Name = "pBox06P2";
            this.pBox06P2.Size = new System.Drawing.Size(44, 39);
            this.pBox06P2.TabIndex = 1;
            this.pBox06P2.TabStop = false;
            // 
            // pBox16P2
            // 
            this.pBox16P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox16P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox16P2.Location = new System.Drawing.Point(1, 187);
            this.pBox16P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox16P2.Name = "pBox16P2";
            this.pBox16P2.Size = new System.Drawing.Size(44, 39);
            this.pBox16P2.TabIndex = 178;
            this.pBox16P2.TabStop = false;
            // 
            // pBox26P2
            // 
            this.pBox26P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox26P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox26P2.Location = new System.Drawing.Point(1, 143);
            this.pBox26P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox26P2.Name = "pBox26P2";
            this.pBox26P2.Size = new System.Drawing.Size(44, 39);
            this.pBox26P2.TabIndex = 181;
            this.pBox26P2.TabStop = false;
            // 
            // pBox36P2
            // 
            this.pBox36P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox36P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox36P2.Location = new System.Drawing.Point(1, 97);
            this.pBox36P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox36P2.Name = "pBox36P2";
            this.pBox36P2.Size = new System.Drawing.Size(44, 39);
            this.pBox36P2.TabIndex = 184;
            this.pBox36P2.TabStop = false;
            // 
            // pBox46P2
            // 
            this.pBox46P2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBox46P2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox46P2.Location = new System.Drawing.Point(1, 53);
            this.pBox46P2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox46P2.Name = "pBox46P2";
            this.pBox46P2.Size = new System.Drawing.Size(44, 39);
            this.pBox46P2.TabIndex = 187;
            this.pBox46P2.TabStop = false;
            // 
            // pBox06P0
            // 
            this.pBox06P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox06P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox06P0.Location = new System.Drawing.Point(1, 231);
            this.pBox06P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox06P0.Name = "pBox06P0";
            this.pBox06P0.Size = new System.Drawing.Size(44, 39);
            this.pBox06P0.TabIndex = 6;
            this.pBox06P0.TabStop = false;
            // 
            // pBox16P0
            // 
            this.pBox16P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox16P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox16P0.Location = new System.Drawing.Point(1, 187);
            this.pBox16P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox16P0.Name = "pBox16P0";
            this.pBox16P0.Size = new System.Drawing.Size(44, 39);
            this.pBox16P0.TabIndex = 179;
            this.pBox16P0.TabStop = false;
            // 
            // pBox26P0
            // 
            this.pBox26P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox26P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox26P0.Location = new System.Drawing.Point(1, 143);
            this.pBox26P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox26P0.Name = "pBox26P0";
            this.pBox26P0.Size = new System.Drawing.Size(44, 39);
            this.pBox26P0.TabIndex = 182;
            this.pBox26P0.TabStop = false;
            // 
            // pBox36P0
            // 
            this.pBox36P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox36P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox36P0.Location = new System.Drawing.Point(1, 97);
            this.pBox36P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox36P0.Name = "pBox36P0";
            this.pBox36P0.Size = new System.Drawing.Size(44, 39);
            this.pBox36P0.TabIndex = 185;
            this.pBox36P0.TabStop = false;
            // 
            // pBox46P0
            // 
            this.pBox46P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox46P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox46P0.Location = new System.Drawing.Point(1, 53);
            this.pBox46P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox46P0.Name = "pBox46P0";
            this.pBox46P0.Size = new System.Drawing.Size(44, 39);
            this.pBox46P0.TabIndex = 188;
            this.pBox46P0.TabStop = false;
            // 
            // pBox56P0
            // 
            this.pBox56P0.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.White;
            this.pBox56P0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBox56P0.Location = new System.Drawing.Point(1, 9);
            this.pBox56P0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBox56P0.Name = "pBox56P0";
            this.pBox56P0.Size = new System.Drawing.Size(44, 39);
            this.pBox56P0.TabIndex = 191;
            this.pBox56P0.TabStop = false;
            // 
            // ExitButt
            // 
            this.ExitButt.BackColor = System.Drawing.SystemColors.Info;
            this.ExitButt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitButt.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ExitButt.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButt.Location = new System.Drawing.Point(340, 423);
            this.ExitButt.Margin = new System.Windows.Forms.Padding(4);
            this.ExitButt.Name = "ExitButt";
            this.ExitButt.Size = new System.Drawing.Size(132, 56);
            this.ExitButt.TabIndex = 178;
            this.ExitButt.Text = "Exit Game";
            this.ExitButt.UseVisualStyleBackColor = false;
            this.ExitButt.Click += new System.EventHandler(this.ExitButt_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Location = new System.Drawing.Point(54, 37);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(47, 40);
            this.panel1.TabIndex = 179;
            this.panel1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col0_MouseClick);
            this.panel1.MouseLeave += new System.EventHandler(this.col0_MouseLeave);
            this.panel1.MouseHover += new System.EventHandler(this.col0_MouseHover);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel2.Location = new System.Drawing.Point(107, 37);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(47, 40);
            this.panel2.TabIndex = 180;
            this.panel2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col1_MouseClick);
            this.panel2.MouseLeave += new System.EventHandler(this.col1_MouseLeave);
            this.panel2.MouseHover += new System.EventHandler(this.col1_MouseHover);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel3.Location = new System.Drawing.Point(160, 37);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(47, 40);
            this.panel3.TabIndex = 180;
            this.panel3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col2_MouseClick);
            this.panel3.MouseLeave += new System.EventHandler(this.col2_MouseLeave);
            this.panel3.MouseHover += new System.EventHandler(this.col2_MouseHover);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel4.Location = new System.Drawing.Point(214, 37);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(47, 40);
            this.panel4.TabIndex = 180;
            this.panel4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col3_MouseClick);
            this.panel4.MouseLeave += new System.EventHandler(this.col3_MouseLeave);
            this.panel4.MouseHover += new System.EventHandler(this.col3_MouseHover);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel5.Location = new System.Drawing.Point(266, 37);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(47, 40);
            this.panel5.TabIndex = 180;
            this.panel5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col4_MouseClick);
            this.panel5.MouseLeave += new System.EventHandler(this.col4_MouseLeave);
            this.panel5.MouseHover += new System.EventHandler(this.col4_MouseHover);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel6.Location = new System.Drawing.Point(316, 37);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(47, 40);
            this.panel6.TabIndex = 180;
            this.panel6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col5_MouseClick);
            this.panel6.MouseLeave += new System.EventHandler(this.col5_MouseLeave);
            this.panel6.MouseHover += new System.EventHandler(this.col5_MouseHover);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Location = new System.Drawing.Point(367, 37);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(47, 40);
            this.panel7.TabIndex = 180;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel8.Location = new System.Drawing.Point(8, 8);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(47, 40);
            this.panel8.TabIndex = 180;
            this.panel8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.col6_MouseClick);
            this.panel8.MouseLeave += new System.EventHandler(this.col6_MouseLeave);
            this.panel8.MouseHover += new System.EventHandler(this.col6_MouseHover);
            // 
            // pBoxPlayer1
            // 
            this.pBoxPlayer1.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Black;
            this.pBoxPlayer1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBoxPlayer1.Location = new System.Drawing.Point(27, 424);
            this.pBoxPlayer1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBoxPlayer1.Name = "pBoxPlayer1";
            this.pBoxPlayer1.Size = new System.Drawing.Size(44, 39);
            this.pBoxPlayer1.TabIndex = 193;
            this.pBoxPlayer1.TabStop = false;
            // 
            // lblPlayer1Name
            // 
            this.lblPlayer1Name.AutoSize = true;
            this.lblPlayer1Name.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayer1Name.Location = new System.Drawing.Point(21, 386);
            this.lblPlayer1Name.Name = "lblPlayer1Name";
            this.lblPlayer1Name.Size = new System.Drawing.Size(112, 36);
            this.lblPlayer1Name.TabIndex = 194;
            this.lblPlayer1Name.Text = "Player1";
            // 
            // lblPlayer2Name
            // 
            this.lblPlayer2Name.AutoSize = true;
            this.lblPlayer2Name.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayer2Name.Location = new System.Drawing.Point(172, 386);
            this.lblPlayer2Name.Name = "lblPlayer2Name";
            this.lblPlayer2Name.Size = new System.Drawing.Size(112, 36);
            this.lblPlayer2Name.TabIndex = 195;
            this.lblPlayer2Name.Text = "Player2";
            // 
            // pBoxPlayer2
            // 
            this.pBoxPlayer2.BackgroundImage = global::CIS153_Connect4_Group3.Properties.Resources.Red;
            this.pBoxPlayer2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pBoxPlayer2.Location = new System.Drawing.Point(178, 424);
            this.pBoxPlayer2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBoxPlayer2.Name = "pBoxPlayer2";
            this.pBoxPlayer2.Size = new System.Drawing.Size(44, 39);
            this.pBoxPlayer2.TabIndex = 265;
            this.pBoxPlayer2.TabStop = false;
            this.pBoxPlayer2.Visible = false;
            // 
            // GameBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 492);
            this.Controls.Add(this.pBoxPlayer2);
            this.Controls.Add(this.lblPlayer2Name);
            this.Controls.Add(this.lblPlayer1Name);
            this.Controls.Add(this.pBoxPlayer1);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ExitButt);
            this.Controls.Add(this.col5Panel);
            this.Controls.Add(this.col6Panel);
            this.Controls.Add(this.col0);
            this.Controls.Add(this.col4Panel);
            this.Controls.Add(this.col3Panel);
            this.Controls.Add(this.col2Panel);
            this.Controls.Add(this.col1Panel);
            this.Controls.Add(this.listView1);
            this.Location = new System.Drawing.Point(100, 100);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "GameBoard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "GameBoard";
            this.Load += new System.EventHandler(this.GameBoard_Load);
            this.col6Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBox51P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox01P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox01P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox01P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox11P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox11P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox11P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox21P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox21P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox21P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox31P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox31P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox31P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox41P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox41P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox41P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox51P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox51P0)).EndInit();
            this.col1Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBox02P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox02P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox02P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox12P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox12P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox12P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox22P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox22P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox22P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox32P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox32P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox32P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox42P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox42P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox42P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox52P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox52P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox52P1)).EndInit();
            this.col2Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBox53P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox03P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox03P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox03P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox13P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox13P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox13P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox23P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox23P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox23P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox33P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox33P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox33P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox43P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox43P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox43P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox53P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox53P0)).EndInit();
            this.col3Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBox54P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox04P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox04P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox14P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox14P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox14P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox24P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox24P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox24P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox34P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox34P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox34P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox44P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox44P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox44P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox54P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox54P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox04P2)).EndInit();
            this.col4Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBox55P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox05P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox05P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox05P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox15P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox15P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox15P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox25P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox25P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox25P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox35P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox35P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox35P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox45P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox45P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox45P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox55P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox55P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox40P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox40P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox30P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox20P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox20P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox40P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox30P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox30P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox20P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox10P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox10P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox10P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox00P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox00P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox50P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox50P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox00P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox50P1)).EndInit();
            this.col0.ResumeLayout(false);
            this.col5Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBox56P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox06P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox16P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox26P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox36P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox46P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox56P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox06P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox16P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox26P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox36P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox46P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox06P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox16P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox26P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox36P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox46P0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox56P0)).EndInit();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBoxPlayer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxPlayer2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Panel col6Panel;
        private System.Windows.Forms.Panel col1Panel;
        private System.Windows.Forms.Panel col2Panel;
        private System.Windows.Forms.Panel col3Panel;
        private System.Windows.Forms.Panel col4Panel;
        private System.Windows.Forms.PictureBox pBox40P2;
        private System.Windows.Forms.PictureBox pBox40P1;
        private System.Windows.Forms.PictureBox pBox30P2;
        private System.Windows.Forms.PictureBox pBox20P2;
        private System.Windows.Forms.PictureBox pBox20P1;
        private System.Windows.Forms.PictureBox pBox40P0;
        private System.Windows.Forms.PictureBox pBox30P1;
        private System.Windows.Forms.PictureBox pBox30P0;
        private System.Windows.Forms.PictureBox pBox20P0;
        private System.Windows.Forms.PictureBox pBox10P2;
        private System.Windows.Forms.PictureBox pBox10P1;
        private System.Windows.Forms.PictureBox pBox10P0;
        private System.Windows.Forms.PictureBox pBox00P1;
        private System.Windows.Forms.PictureBox pBox00P0;
        private System.Windows.Forms.PictureBox pBox50P0;
        private System.Windows.Forms.PictureBox pBox50P2;
        private System.Windows.Forms.PictureBox pBox00P2;
        private System.Windows.Forms.PictureBox pBox50P1;
        private System.Windows.Forms.Panel col0;
        private System.Windows.Forms.Panel col5Panel;
        private System.Windows.Forms.PictureBox pBox56P1;
        private System.Windows.Forms.PictureBox pBox06P1;
        private System.Windows.Forms.PictureBox pBox16P1;
        private System.Windows.Forms.PictureBox pBox26P1;
        private System.Windows.Forms.PictureBox pBox36P1;
        private System.Windows.Forms.PictureBox pBox46P1;
        private System.Windows.Forms.PictureBox pBox56P2;
        private System.Windows.Forms.PictureBox pBox06P2;
        private System.Windows.Forms.PictureBox pBox16P2;
        private System.Windows.Forms.PictureBox pBox26P2;
        private System.Windows.Forms.PictureBox pBox36P2;
        private System.Windows.Forms.PictureBox pBox46P2;
        private System.Windows.Forms.PictureBox pBox06P0;
        private System.Windows.Forms.PictureBox pBox16P0;
        private System.Windows.Forms.PictureBox pBox26P0;
        private System.Windows.Forms.PictureBox pBox36P0;
        private System.Windows.Forms.PictureBox pBox46P0;
        private System.Windows.Forms.PictureBox pBox56P0;
        private System.Windows.Forms.PictureBox pBox51P1;
        private System.Windows.Forms.PictureBox pBox51P0;
        private System.Windows.Forms.PictureBox pBox51P2;
        private System.Windows.Forms.PictureBox pBox41P1;
        private System.Windows.Forms.PictureBox pBox41P0;
        private System.Windows.Forms.PictureBox pBox41P2;
        private System.Windows.Forms.PictureBox pBox31P1;
        private System.Windows.Forms.PictureBox pBox31P0;
        private System.Windows.Forms.PictureBox pBox31P2;
        private System.Windows.Forms.PictureBox pBox21P1;
        private System.Windows.Forms.PictureBox pBox21P0;
        private System.Windows.Forms.PictureBox pBox21P2;
        private System.Windows.Forms.PictureBox pBox11P1;
        private System.Windows.Forms.PictureBox pBox11P0;
        private System.Windows.Forms.PictureBox pBox11P2;
        private System.Windows.Forms.PictureBox pBox01P1;
        private System.Windows.Forms.PictureBox pBox01P0;
        private System.Windows.Forms.PictureBox pBox01P2;
        private System.Windows.Forms.PictureBox pBox02P1;
        private System.Windows.Forms.PictureBox pBox02P2;
        private System.Windows.Forms.PictureBox pBox02P0;
        private System.Windows.Forms.PictureBox pBox12P2;
        private System.Windows.Forms.PictureBox pBox12P0;
        private System.Windows.Forms.PictureBox pBox12P1;
        private System.Windows.Forms.PictureBox pBox22P2;
        private System.Windows.Forms.PictureBox pBox22P0;
        private System.Windows.Forms.PictureBox pBox22P1;
        private System.Windows.Forms.PictureBox pBox32P2;
        private System.Windows.Forms.PictureBox pBox32P0;
        private System.Windows.Forms.PictureBox pBox32P1;
        private System.Windows.Forms.PictureBox pBox42P2;
        private System.Windows.Forms.PictureBox pBox42P0;
        private System.Windows.Forms.PictureBox pBox42P1;
        private System.Windows.Forms.PictureBox pBox52P2;
        private System.Windows.Forms.PictureBox pBox52P0;
        private System.Windows.Forms.PictureBox pBox52P1;
        private System.Windows.Forms.PictureBox pBox53P1;
        private System.Windows.Forms.PictureBox pBox03P2;
        private System.Windows.Forms.PictureBox pBox03P0;
        private System.Windows.Forms.PictureBox pBox03P1;
        private System.Windows.Forms.PictureBox pBox13P2;
        private System.Windows.Forms.PictureBox pBox13P0;
        private System.Windows.Forms.PictureBox pBox13P1;
        private System.Windows.Forms.PictureBox pBox23P2;
        private System.Windows.Forms.PictureBox pBox23P0;
        private System.Windows.Forms.PictureBox pBox23P1;
        private System.Windows.Forms.PictureBox pBox33P2;
        private System.Windows.Forms.PictureBox pBox33P0;
        private System.Windows.Forms.PictureBox pBox33P1;
        private System.Windows.Forms.PictureBox pBox43P2;
        private System.Windows.Forms.PictureBox pBox43P0;
        private System.Windows.Forms.PictureBox pBox43P1;
        private System.Windows.Forms.PictureBox pBox53P2;
        private System.Windows.Forms.PictureBox pBox53P0;
        private System.Windows.Forms.PictureBox pBox54P1;
        private System.Windows.Forms.PictureBox pBox04P2;
        private System.Windows.Forms.PictureBox pBox04P0;
        private System.Windows.Forms.PictureBox pBox04P1;
        private System.Windows.Forms.PictureBox pBox14P2;
        private System.Windows.Forms.PictureBox pBox14P0;
        private System.Windows.Forms.PictureBox pBox14P1;
        private System.Windows.Forms.PictureBox pBox24P2;
        private System.Windows.Forms.PictureBox pBox24P0;
        private System.Windows.Forms.PictureBox pBox24P1;
        private System.Windows.Forms.PictureBox pBox34P2;
        private System.Windows.Forms.PictureBox pBox34P0;
        private System.Windows.Forms.PictureBox pBox34P1;
        private System.Windows.Forms.PictureBox pBox44P2;
        private System.Windows.Forms.PictureBox pBox44P0;
        private System.Windows.Forms.PictureBox pBox44P1;
        private System.Windows.Forms.PictureBox pBox54P2;
        private System.Windows.Forms.PictureBox pBox54P0;
        private System.Windows.Forms.PictureBox pBox55P1;
        private System.Windows.Forms.PictureBox pBox05P2;
        private System.Windows.Forms.PictureBox pBox05P0;
        private System.Windows.Forms.PictureBox pBox05P1;
        private System.Windows.Forms.PictureBox pBox15P2;
        private System.Windows.Forms.PictureBox pBox15P0;
        private System.Windows.Forms.PictureBox pBox15P1;
        private System.Windows.Forms.PictureBox pBox25P2;
        private System.Windows.Forms.PictureBox pBox25P0;
        private System.Windows.Forms.PictureBox pBox25P1;
        private System.Windows.Forms.PictureBox pBox35P2;
        private System.Windows.Forms.PictureBox pBox35P0;
        private System.Windows.Forms.PictureBox pBox35P1;
        private System.Windows.Forms.PictureBox pBox45P2;
        private System.Windows.Forms.PictureBox pBox45P0;
        private System.Windows.Forms.PictureBox pBox45P1;
        private System.Windows.Forms.PictureBox pBox55P2;
        private System.Windows.Forms.PictureBox pBox55P0;
        private System.Windows.Forms.Button ExitButt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.PictureBox pBoxPlayer1;
        private System.Windows.Forms.Label lblPlayer1Name;
        private System.Windows.Forms.Label lblPlayer2Name;
        private System.Windows.Forms.PictureBox pBoxPlayer2;
    }
}