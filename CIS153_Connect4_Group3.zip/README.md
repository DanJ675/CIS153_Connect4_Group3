# CIS153_Connect4_Group3
Connect 4 Group 3

This is a 2 player connect-4 game where you can choose either two players or play against the computer, new players can be added on the home screen and all player data is persistent.